import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Example {
    public static void main(String[] args) {
        String db = "postgres";
        String ip = "localhost";
        short port = 5432;

        String url = "jdbc:postgresql://" + ip + ":" + port + "/" + db;
        String user = "postgres";
        String password = "qwerty123";

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connection successful.");

            String sql = "SELECT * FROM bar.employee WHERE salary > ?";

            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, 2000);

            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                System.out.println(resultSet.getInt("id") + " " + resultSet.getString("name") + " " + resultSet.getInt("salary"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
