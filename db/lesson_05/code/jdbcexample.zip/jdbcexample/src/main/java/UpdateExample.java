import java.sql.*;

public class UpdateExample {
    public static void main(String[] args) {
        String db = "postgres";
        String ip = "localhost";
        short port = 5432;

        String url = "jdbc:postgresql://" + ip + ":" + port + "/" + db;
        String user = "postgres";
        String password = "qwerty123";

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connection successful.");

            String sql = "UPDATE bar.employee SET salary = ? WHERE salary < ? AND name LIKE ?";
            int minSalary = 2200;
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, minSalary);
            preparedStatement.setInt(2, minSalary);

            boolean rowsAffected = preparedStatement.execute();
            System.out.println("Rows affected: " + rowsAffected);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
