package com.ait.example.dao;

import com.ait.example.manager.DBManager;
import com.ait.example.model.Employee;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class EmployeeDao implements Dao<Employee> {
    private Map<Long, Employee> employees = new HashMap();

    public EmployeeDao() {
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            String sql = "SELECT * FROM bar.employee";

            preparedStatement = DBManager.getInstance().prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Employee emp = new Employee(resultSet.getLong("id"), resultSet.getString("name"),
                        resultSet.getLong("id_job"), resultSet.getLong("salary"));
                employees.put(emp.getId(), emp);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Override
    public Optional<Employee> get(long id) {
        Employee emp = employees.get(id);
        return emp == null ? Optional.empty() : Optional.of(emp);
    }

    @Override
    public List<Employee> getAll() {
        return new ArrayList<>(employees.values());
    }

    @Override
    public void save(Employee employee) {
        PreparedStatement preparedStatement = null;
        try {
            String sql = "INSERT INTO bar.employee (id, name, id_job, salary) VALUES (?,?,?,?)";
            preparedStatement = DBManager.getInstance().prepareStatement(sql);
            preparedStatement.setLong(1, employee.getId());
            preparedStatement.setString(2, employee.getName());
            preparedStatement.setLong(3, employee.getId_job());
            preparedStatement.setLong(4, employee.getSalary());

            preparedStatement.execute();

            employees.put(employee.getId(), employee);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }

    }

    @Override
    public void update(long id, Employee newModel) {
        PreparedStatement preparedStatement = null;
        try {
            String sql = "UPDATE bar.employee SET name = ?, id_job = ?, salary = ? WHERE id = ?";
            preparedStatement = DBManager.getInstance().prepareStatement(sql);
            preparedStatement.setString(1, newModel.getName());
            preparedStatement.setLong(2, newModel.getId_job());
            preparedStatement.setLong(3, newModel.getSalary());
            preparedStatement.setLong(4, id);

            preparedStatement.execute();

            employees.put(id, newModel);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }


    @Override
    public void delete(long id) {
        PreparedStatement preparedStatement = null;
        try {
            String sql = "DELETE FROM bar.employee WHERE id = ?";
            preparedStatement = DBManager.getInstance().prepareStatement(sql);
            preparedStatement.setLong(1, id);

            preparedStatement.execute();

            employees.remove(id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
