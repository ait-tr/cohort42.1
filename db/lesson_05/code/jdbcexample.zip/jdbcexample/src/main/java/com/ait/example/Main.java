package com.ait.example;

import com.ait.example.dao.EmployeeDao;
import com.ait.example.manager.DBManager;
import com.ait.example.model.Employee;

import java.sql.*;

public class Main {
    public static void main(String[] args) throws SQLException {
        String db = "postgres";
        String ip = "localhost";
        short port = 5432;

        String url = "jdbc:postgresql://" + ip + ":" + port + "/" + db;
        String user = "postgres";
        String password = "qwerty123";
        DBManager.getInstance().connect(url, user, password);
        EmployeeDao employeeDao = new EmployeeDao();

        employeeDao.delete(6);
        Employee employee = employeeDao.get(3).get();
        employee.setSalary(3100);
        employeeDao.update(3, employee);

        for (Employee e : employeeDao.getAll()) {
            System.out.println(e);
        }
    }
}
